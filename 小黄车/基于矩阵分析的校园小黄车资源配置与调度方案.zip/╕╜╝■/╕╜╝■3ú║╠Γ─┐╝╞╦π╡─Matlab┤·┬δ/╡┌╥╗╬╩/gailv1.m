%�淶����
p=xlsread('����1.xls')
sum=zeros(1,12);
for i=1:12
    for j=1:12
        if i~=j
            sum(i)=p(i,j)+sum(i);
        end
    end
    p(i,i)=1-sum(i);
end
xlswrite('p1.xls',p)
