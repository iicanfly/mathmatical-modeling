function shuliang2
clc
%ȷ��С�Ƴ�����2.0
%Dijkstra�㷨ȷ�����·��
A=xlsread('���·��.xls')
a=zeros(12,12);%����֮�����·�����ɴ����
for i=1:12
    for j=1:12
        if i~=j
            a(i,j)=dijkstra(A,i,j);
        end
    end
end
a
dijkstra(A,7,6)
dijkstra(A,6,7)
% %�涨�ȴ�ʱ��Ϊ10min���������833.34�� 
% for i=1:12
%     for j=1:12
%         if a(i,j)<833.34
%             a(i,j)=1;%�ڵȴ�ʱ���ڿ��Թ���
%         else
%             a(i,j)=0;%�ڵȴ�ʱ���ڲ��ɹ���
%         end
%     end
% end
% 
% 
% %ȷ��С�Ƴ�����1.0
% y=cell(1,12);%��ͬʱ�̵�ʦ���ֲ�
% x=cell(1,11);%״̬�仯
% chushi=[0 0 200 0 0 100 5280 8580 11220 0 100 0];%��ʼʦ���ֲ�
% y{1}=diag(chushi);
%  p=cell(1,11);%����
% p{1}=xlsread('p1.xls');
% p{2}=xlsread('p2.xls');
% p{3}=xlsread('p3.xls');
% p{4}=xlsread('p4.xls');
% p{5}=xlsread('p5.xls');
% p{6}=xlsread('p6.xls');
% p{7}=xlsread('p7.xls');
% p{8}=xlsread('p8.xls');
% p{9}=xlsread('p9.xls');
% p{10}=xlsread('p10.xls');
% p{11}=xlsread('p11.xls');
% lai=zeros(11,11);%�����ĳ���
% qu=zeros(11,11);%�뿪�ĳ���
% for i=1:11%��ͬʱ��
%        x{i}=y{i}*p{i};
%        temp=zeros(12);
%        b=zeros(1,12);
%        for k=1:12
%           h=x{i}(:,k);
%            b(k)=sum(h);
%       end
% 
%        y{i+1}=diag(b);
%      for j=1:12%��ͬ�ص�
%          qu(j,i)=sum(x{i}(j,:))-x{i}(j,j);
%          x{i}(:,j)=a(:,j).*x{i}(:,j);
%         lai(j,i)=sum(x{i}(:,j))-x{i}(j,j);
%       end
% end
% %ȷ��С�Ƴ�����
% a=zeros(1,11);
% d=zeros(1,11);
% for i=1:12 %��ͬ�ص�
%     a(1)=qu(i,1)-lai(i,1);
%     for j=2:11%��ͬʱ��
%         a(j)=a(j-1)+qu(i,j)-lai(i,j);
%     end
%     d(i)=max(a);
% end
% sum1=0;
% for i=1:12
%     if d(i)>0
%         sum1=sum1+d(i);
%     end
% end
% d
% sum1
% 
%dijkstra�㷨
function distance=dijkstra(A,s,e)
% A: adjcent matrix
% s: start node
% e: end node
% [distance,path]=dijkstra(A,s,e)
% return the distance and path between the start node and the end node.

% initialize
n=size(A,1);        % node number
D=A(s,:);           % distance vector
path=[];            % path vector
visit=ones(1,n);    % node visibility
visit(s)=0;         % source node is unvisible
parent=zeros(1,n);  % parent node
% the shortest distance
for i=1:n-1         % BlueSet has n-1 nodes
    temp=[];
    for j=1:n
        if visit(j)
            temp=[temp D(j)];
        else
            temp=[temp inf];
        end
    end
    [value,index]=min(temp);
    j=index; visit(j)=0;
    for k=1:n
        if D(k)>D(j)+A(j,k)
            D(k)=D(j)+A(j,k);
            parent(k)=j;
        end
    end
end
distance=D(e);

% the shortest distance path
if parent(e)==0, return; end

% there is a shortest distance path
t=e; path=t;
while t~=s && t>0
    p=parent(t);
    path=[p path];
    t=p;
end
path(1)=s;



