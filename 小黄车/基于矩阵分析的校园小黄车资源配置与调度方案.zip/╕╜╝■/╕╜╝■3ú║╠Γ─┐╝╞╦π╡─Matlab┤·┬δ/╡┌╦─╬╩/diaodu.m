function lujin
%3Ϊ��ʼ��
%�ó�
zuiduanlujing=[];
juli=inf;
for k=1:12
    N=720;%��������
    qidian=k*ones(720,1);
    s=perms([1,2,7,10,11,12]);
    lujing=xlsread('���·��1.xls');
    s=[qidian s qidian];
    dis=zeros(1,7);
    Dis=zeros(1,720);
    for i=1:720
        dis=zeros(1,7);
        for j=1:7
            m=s(i,j);
            n=s(i,j+1);
            dis(j)=lujing(m,n)+dis(j);
        end
        Dis(i)=sum(dis);
    end
    [A,index]=sort(Dis);
    s(index(1),:);
    A(1);
    %�ų�
    N=720;%��������
    S=perms([3,4,5,6,8,9]);
    S=[qidian S qidian];
    dis=zeros(1,7);
    Dis=zeros(1,720);
    for i=1:720
        dis=zeros(1,7);
        for j=1:7
            m=S(i,j);
            n=S(i,j+1);
            dis(j)=lujing(m,n)+dis(j);
        end
        Dis(i)=sum(dis);
    end
    [a,Index]=sort(Dis);
    S(Index(1),:);
    a(1);
    if  a(1)+A(1)<= juli
       juli=a(1)+A(1);
       zuiduanlujing=[zuiduanlujing
           s(index(1),:) S(Index(1),:)];
    end
end
juli
xlswrite('�����ʽ��.xls',zuiduanlujing)

 
