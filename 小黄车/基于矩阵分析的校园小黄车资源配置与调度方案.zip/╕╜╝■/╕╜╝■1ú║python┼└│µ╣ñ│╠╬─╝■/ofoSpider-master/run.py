from ofoSpider import *

c = spider.Crawler()
c.start()
print("完成")