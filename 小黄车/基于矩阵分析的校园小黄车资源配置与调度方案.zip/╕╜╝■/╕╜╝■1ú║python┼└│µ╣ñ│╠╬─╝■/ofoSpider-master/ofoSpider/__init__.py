from .spider import *

print ("ofoSpider Module Loaded!")
print ("Author: SilverBooker")